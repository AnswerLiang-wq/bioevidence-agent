"""BioEvidence Agent public-benchmark product package."""

__version__ = "0.3.0"

__all__ = ["__version__"]
